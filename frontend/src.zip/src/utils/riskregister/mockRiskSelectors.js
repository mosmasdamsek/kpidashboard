const matchesFilter = (value, filterValue) => {
  if (!filterValue || filterValue === "all" || filterValue === "current") {
    return true;
  }
  return value === filterValue;
};

export const filterRiskItems = (items, filters) => {
  return items.filter((item) => {
    const periodMatch =
      filters.reporting_period === "all" ||
      filters.reporting_period === "current" ||
      item.reporting_period === filters.reporting_period;

    return (
      periodMatch &&
      matchesFilter(item.department, filters.department) &&
      matchesFilter(item.category, filters.category) &&
      matchesFilter(item.owner, filters.owner)
    );
  });
};

export const filterActionItems = (items, filters) => {
  return items.filter((item) => {
    const periodMatch =
      filters.reporting_period === "all" ||
      filters.reporting_period === "current" ||
      item.reporting_period === filters.reporting_period;

    return (
      periodMatch &&
      matchesFilter(item.department, filters.department) &&
      matchesFilter(item.category, filters.category) &&
      matchesFilter(item.owner, filters.owner)
    );
  });
};

export const buildSummaryFromRisks = (risks, actions) => ({
  total_risks: risks.length,
  critical_risks: risks.filter((r) => r.rating === "Critical").length,
  high_risks: risks.filter((r) => r.rating === "High").length,
  overdue_actions: actions.filter((a) => a.status === "Overdue").length,
  open_issues: risks.filter((r) => r.status === "Open").length,
  upcoming_reviews: 4,
});

export const buildCategoryChart = (risks) => {
  const grouped = risks.reduce((acc, item) => {
    acc[item.category] = (acc[item.category] || 0) + 1;
    return acc;
  }, {});

  return Object.entries(grouped).map(([name, value]) => ({ name, value }));
};

export const buildDivisionChart = (risks) => {
  const grouped = risks.reduce((acc, item) => {
    acc[item.department] = (acc[item.department] || 0) + 1;
    return acc;
  }, {});

  return Object.entries(grouped).map(([name, value]) => ({ name, value }));
};

export const buildTrendChart = (risks) => {
  const order = ["Jan", "Feb", "Mar", "Apr"];
  const grouped = { Jan: 0, Feb: 0, Mar: 0, Apr: 0 };

  risks.forEach((item) => {
    if (grouped[item.trend_period] !== undefined) {
      grouped[item.trend_period] += 1;
    }
  });

  return order.map((period) => ({
    period,
    value: grouped[period],
  }));
};

export const buildHeatmap = (risks) => {
  const grouped = {};

  risks.forEach((item) => {
    const key = `${item.likelihood}-${item.impact}`;
    grouped[key] = (grouped[key] || 0) + 1;
  });

  return Object.entries(grouped).map(([key, count]) => {
    const [likelihood, impact] = key.split("-").map(Number);
    return { likelihood, impact, count };
  });
};

export const buildCriticalRisks = (risks) =>
  risks.filter((r) => r.rating === "Critical");

export const buildOverdueActions = (actions) =>
  actions.filter((a) => a.status === "Overdue");

export const filterRiskItemsForList = (items, filters) => {
  return items.filter((item) => {
    const search = (filters.search || "").trim().toLowerCase();

    const matchesSearch =
      !search ||
      item.risk_number.toLowerCase().includes(search) ||
      item.description.toLowerCase().includes(search) ||
      item.category.toLowerCase().includes(search) ||
      item.department.toLowerCase().includes(search) ||
      item.owner.toLowerCase().includes(search);

    const matchesCategory =
      !filters.category || filters.category === "all" || item.category === filters.category;

    const matchesDepartment =
      !filters.department || filters.department === "all" || item.department === filters.department;

    const matchesRating =
      !filters.rating || filters.rating === "all" || item.rating === filters.rating;

    const matchesStatus =
      !filters.status || filters.status === "all" || item.status === filters.status;

    return (
      matchesSearch &&
      matchesCategory &&
      matchesDepartment &&
      matchesRating &&
      matchesStatus
    );
  });
};


export const filterActionItemsForList = (items, filters) => {
  return items.filter((item) => {
    const search = (filters.search || "").trim().toLowerCase();

    const matchesSearch =
      !search ||
      item.risk.toLowerCase().includes(search) ||
      item.action.toLowerCase().includes(search) ||
      item.owner.toLowerCase().includes(search) ||
      item.category.toLowerCase().includes(search) ||
      item.department.toLowerCase().includes(search);

    const matchesDepartment =
      !filters.department || filters.department === "all" || item.department === filters.department;

    const matchesCategory =
      !filters.category || filters.category === "all" || item.category === filters.category;

    const matchesStatus =
      !filters.status || filters.status === "all" || item.status === filters.status;

    const periodMatch =
      !filters.reporting_period ||
      filters.reporting_period === "all" ||
      filters.reporting_period === "current" ||
      item.reporting_period === filters.reporting_period;

    return (
      matchesSearch &&
      matchesDepartment &&
      matchesCategory &&
      matchesStatus &&
      periodMatch
    );
  });
};

export const filterReviewItemsForList = (items, filters) => {
  return items.filter((item) => {
    const search = (filters.search || "").trim().toLowerCase();

    const matchesSearch =
      !search ||
      item.risk.toLowerCase().includes(search) ||
      item.reviewer.toLowerCase().includes(search) ||
      item.comments.toLowerCase().includes(search) ||
      item.category.toLowerCase().includes(search) ||
      item.department.toLowerCase().includes(search);

    const matchesDepartment =
      !filters.department || filters.department === "all" || item.department === filters.department;

    const matchesCategory =
      !filters.category || filters.category === "all" || item.category === filters.category;

    const periodMatch =
      !filters.reporting_period ||
      filters.reporting_period === "all" ||
      filters.reporting_period === "current" ||
      item.reporting_period === filters.reporting_period;

    return matchesSearch && matchesDepartment && matchesCategory && periodMatch;
  });
};