import React from "react";
import { Grid, MenuItem, Paper, TextField } from "@mui/material";

const RiskActionsToolbar = ({ filters, onChange }) => {
  const handleChange = (field) => (event) => {
    onChange((prev) => ({
      ...prev,
      [field]: event.target.value,
    }));
  };

  return (
    <Paper sx={{ p: 2.5, borderRadius: 4 }}>
      <Grid container spacing={2}>
        <Grid item xs={12} md={4}>
          <TextField
            fullWidth
            label="Search actions"
            value={filters.search}
            onChange={handleChange("search")}
            placeholder="Risk, action, owner..."
          />
        </Grid>

        <Grid item xs={12} sm={6} md={2}>
          <TextField
            fullWidth
            select
            label="Department"
            value={filters.department}
            onChange={handleChange("department")}
          >
            <MenuItem value="all">All</MenuItem>
            <MenuItem value="Operations">Operations</MenuItem>
            <MenuItem value="Finance">Finance</MenuItem>
            <MenuItem value="Commercial">Commercial</MenuItem>
            <MenuItem value="HR">HR</MenuItem>
            <MenuItem value="IT">IT</MenuItem>
          </TextField>
        </Grid>

        <Grid item xs={12} sm={6} md={2}>
          <TextField
            fullWidth
            select
            label="Category"
            value={filters.category}
            onChange={handleChange("category")}
          >
            <MenuItem value="all">All</MenuItem>
            <MenuItem value="Operational">Operational</MenuItem>
            <MenuItem value="Financial">Financial</MenuItem>
            <MenuItem value="Compliance">Compliance</MenuItem>
            <MenuItem value="Strategic">Strategic</MenuItem>
            <MenuItem value="Technology">Technology</MenuItem>
          </TextField>
        </Grid>

        <Grid item xs={12} sm={6} md={2}>
          <TextField
            fullWidth
            select
            label="Status"
            value={filters.status}
            onChange={handleChange("status")}
          >
            <MenuItem value="all">All</MenuItem>
            <MenuItem value="Overdue">Overdue</MenuItem>
            <MenuItem value="In Progress">In Progress</MenuItem>
            <MenuItem value="Completed">Completed</MenuItem>
          </TextField>
        </Grid>

        <Grid item xs={12} sm={6} md={2}>
          <TextField
            fullWidth
            select
            label="Period"
            value={filters.reporting_period}
            onChange={handleChange("reporting_period")}
          >
            <MenuItem value="current">Current</MenuItem>
            <MenuItem value="q1">Q1</MenuItem>
            <MenuItem value="q2">Q2</MenuItem>
            <MenuItem value="q3">Q3</MenuItem>
            <MenuItem value="q4">Q4</MenuItem>
            <MenuItem value="all">All</MenuItem>
          </TextField>
        </Grid>
      </Grid>
    </Paper>
  );
};

export default RiskActionsToolbar;