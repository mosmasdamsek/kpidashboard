import React from "react";
import {
  Box,
  Chip,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
  Typography,
} from "@mui/material";
import { useNavigate } from "react-router-dom";

const ratingColorMap = {
  Critical: "error",
  High: "warning",
  Medium: "info",
  Low: "success",
};

const statusColorMap = {
  Open: "default",
  "In Progress": "info",
  Closed: "success",
};

const RiskItemsTable = ({ rows }) => {
  const navigate = useNavigate();

  return (
    <Paper sx={{ p: 2.5, borderRadius: 4 }}>
      <Typography variant="h6" fontWeight={700} sx={{ mb: 2 }}>
        Risk Items
      </Typography>

      {rows.length === 0 ? (
        <Typography color="text.secondary">No risks found.</Typography>
      ) : (
        <Box sx={{ overflowX: "auto" }}>
          <Table size="small">
            <TableHead>
              <TableRow>
                <TableCell><strong>Risk No.</strong></TableCell>
                <TableCell><strong>Description</strong></TableCell>
                <TableCell><strong>Category</strong></TableCell>
                <TableCell><strong>Department</strong></TableCell>
                <TableCell><strong>Owner</strong></TableCell>
                <TableCell><strong>Rating</strong></TableCell>
                <TableCell><strong>Status</strong></TableCell>
              </TableRow>
            </TableHead>

            <TableBody>
              {rows.map((row) => (
                <TableRow
                  key={row.id}
                  hover
                  sx={{ cursor: "pointer" }}
                  onClick={() => navigate(`/risk-register/items/${row.id}`)}
                >
                  <TableCell>{row.risk_number}</TableCell>
                  <TableCell>{row.description}</TableCell>
                  <TableCell>{row.category}</TableCell>
                  <TableCell>{row.department}</TableCell>
                  <TableCell>{row.owner}</TableCell>
                  <TableCell>
                    <Chip
                      label={row.rating}
                      size="small"
                      color={ratingColorMap[row.rating] || "default"}
                      variant="outlined"
                    />
                  </TableCell>
                  <TableCell>
                    <Chip
                      label={row.status}
                      size="small"
                      color={statusColorMap[row.status] || "default"}
                      variant="outlined"
                    />
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </Box>
      )}
    </Paper>
  );
};

export default RiskItemsTable;