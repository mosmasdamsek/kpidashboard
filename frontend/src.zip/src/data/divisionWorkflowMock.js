export const divisionWorkflowMock = {
  division: {
    id: "finance",
    name: "Finance",
    periodId: "2026-q1",
    periodName: "Q1 2026",
    divisionHead: "Elena Volkov",
    role: "CFO",
    status: "submitted",
    score: 88,
  },

  departments: [
    {
      id: "dep-001",
      department: "Finance Operations",
      owner: "K. Molefe",
      score: 91,
      status: "approved",
      highlights: "Strong revenue performance, cost pressure noted.",
    },
    {
      id: "dep-002",
      department: "Revenue Assurance",
      owner: "T. Dube",
      score: 84,
      status: "submitted",
      highlights: "Collections improving, reconciliation backlog remains.",
    },
    {
      id: "dep-003",
      department: "Treasury",
      owner: "L. Mpho",
      score: 88,
      status: "approved",
      highlights: "Cash flow healthy, minor delay in reporting pack.",
    },
  ],

  kpis: [
    { name: "Revenue", target: 8000000, actual: 7450000, achievement: 93.1 },
    { name: "Cost Efficiency", target: 2400000, actual: 2515000, achievement: 95.4 },
    { name: "Customer Satisfaction", target: 90, actual: 92, achievement: 102.2 },
    { name: "Collections", target: 95, actual: 97.2, achievement: 102.3 },
  ],

  commentary: {
    executiveSummary: "",
    achievements: "",
    risks: "",
    supportNeeded: "",
  },

  preview: {
    metrics: [
      { name: "Revenue", value: "BWP 7.45M", change: "+6.8%", tone: "#22c55e" },
      { name: "Cost Efficiency", value: "95.4%", change: "-1.2%", tone: "#f59e0b" },
      { name: "Customer Satisfaction", value: "92%", change: "+2.0%", tone: "#22c55e" },
      { name: "Collections", value: "97.2%", change: "+4.7%", tone: "#22c55e" },
    ],
    narrative: {
      summary:
        "The division recorded strong performance overall, supported by improved collections, healthy cash flow, and strong departmental coordination. Revenue performance remained below stretch expectations due to timing of major client receipts, while customer satisfaction improved beyond target.",
      achievements:
        "Collections exceeded target, department approvals improved workflow consistency, and customer-facing performance indicators remained healthy.",
      risks:
        "Cost overruns in selected operational areas and delays in a few upstream submissions affected the final divisional score.",
      supportNeeded:
        "Continued support is needed for process standardization, timely source submissions, and visibility into cost drivers across departments.",
    },
  },
};