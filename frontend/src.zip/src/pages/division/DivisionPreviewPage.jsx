import React from "react";
import {
  Box,
  Button,
  CardContent,
  Divider,
  Stack,
  Typography,
} from "@mui/material";
import WorkspaceLayout from "../../layouts/WorkspaceLayout";
import GlassCard from "../../components/common/GlassCard";
import StatusChip from "../../components/common/StatusChip";
import CircularScore from "../../components/common/CircularScore";
import { softText, white } from "../../theme/dashboardTokens";
import useDivisionWorkflowData from "../../features/reporting/hooks/useDivisionWorkflowData";

const DivisionPreviewPage = () => {
  const { division, departments, preview } = useDivisionWorkflowData();

  return (
    <WorkspaceLayout
      role="division"
      title="Division Preview"
      subtitle="Preview the divisional submission before final upward review."
      actions={<StatusChip status={division.status} label="Preview Ready" />}
    >
      <Stack spacing={3}>
        <GlassCard>
          <CardContent>
            <Box className="flex flex-col gap-5 xl:flex-row xl:items-center xl:justify-between">
              <Box>
                <Typography sx={{ fontSize: 28, fontWeight: 900, color: white }}>
                  {division.name} Division
                </Typography>
                <Typography sx={{ color: softText, mt: 0.75 }}>
                  {division.periodName} divisional submission preview for upward reporting.
                </Typography>
              </Box>

              <CircularScore value={division.score} color="#8b5cf6" />
            </Box>
          </CardContent>
        </GlassCard>

        <GlassCard>
          <CardContent>
            <Typography sx={{ fontSize: 18, fontWeight: 800, mb: 2 }}>
              Key Divisional Metrics
            </Typography>

            <Box className="grid grid-cols-1 gap-3 md:grid-cols-2 xl:grid-cols-4">
              {preview.metrics.map((metric) => (
                <Box
                  key={metric.name}
                  sx={{
                    p: 2,
                    borderRadius: 3,
                    bgcolor: "rgba(255,255,255,0.03)",
                    border: "1px solid rgba(255,255,255,0.06)",
                  }}
                >
                  <Typography sx={{ fontSize: 12.5, color: softText }}>
                    {metric.name}
                  </Typography>
                  <Typography sx={{ fontSize: 22, fontWeight: 900, mt: 1, color: white }}>
                    {metric.value}
                  </Typography>
                  <Typography sx={{ fontSize: 13, fontWeight: 800, mt: 0.8, color: metric.tone }}>
                    {metric.change}
                  </Typography>
                </Box>
              ))}
            </Box>
          </CardContent>
        </GlassCard>

        <GlassCard>
          <CardContent>
            <Typography sx={{ fontSize: 18, fontWeight: 800, mb: 2 }}>
              Department Contributions
            </Typography>

            <Stack spacing={1.5}>
              {departments.map((item) => (
                <Box
                  key={item.id}
                  className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between"
                  sx={{
                    p: 2,
                    borderRadius: 3,
                    bgcolor: "rgba(255,255,255,0.03)",
                    border: "1px solid rgba(255,255,255,0.06)",
                  }}
                >
                  <Box>
                    <Typography sx={{ fontWeight: 800, color: white }}>
                      {item.department}
                    </Typography>
                    <Typography sx={{ color: softText, fontSize: 12.5, mt: 0.4 }}>
                      Department score: {item.score}%
                    </Typography>
                  </Box>

                  <StatusChip status={item.status} />
                </Box>
              ))}
            </Stack>
          </CardContent>
        </GlassCard>

        <GlassCard>
          <CardContent>
            <Typography sx={{ fontSize: 18, fontWeight: 800, mb: 2 }}>
              Executive Narrative Preview
            </Typography>

            <Typography sx={{ color: white, lineHeight: 1.8 }}>
              {preview.narrative.summary}
            </Typography>

            <Divider sx={{ my: 2.5, borderColor: "rgba(148,163,184,0.12)" }} />

            <Typography sx={{ fontSize: 15, fontWeight: 800, mb: 1 }}>
              Major Achievements
            </Typography>
            <Typography sx={{ color: white, lineHeight: 1.8 }}>
              {preview.narrative.achievements}
            </Typography>

            <Typography sx={{ fontSize: 15, fontWeight: 800, mt: 2.5, mb: 1 }}>
              Risks and Challenges
            </Typography>
            <Typography sx={{ color: white, lineHeight: 1.8 }}>
              {preview.narrative.risks}
            </Typography>

            <Typography sx={{ fontSize: 15, fontWeight: 800, mt: 2.5, mb: 1 }}>
              Support Required
            </Typography>
            <Typography sx={{ color: white, lineHeight: 1.8 }}>
              {preview.narrative.supportNeeded}
            </Typography>

            <Box className="mt-4 flex flex-wrap items-center gap-2">
              <Button variant="outlined" sx={{ textTransform: "none" }}>
                Back to Commentary
              </Button>
              <Button variant="contained" sx={{ textTransform: "none" }}>
                Submit Upward
              </Button>
            </Box>
          </CardContent>
        </GlassCard>
      </Stack>
    </WorkspaceLayout>
  );
};

export default DivisionPreviewPage;