import React from "react";
import {
  Box,
  Button,
  CardContent,
  LinearProgress,
  Stack,
  Typography,
} from "@mui/material";
import WorkspaceLayout from "../../layouts/WorkspaceLayout";
import GlassCard from "../../components/common/GlassCard";
import StatusChip from "../../components/common/StatusChip";
import { line, panel2, softText, white } from "../../theme/dashboardTokens";
import useDivisionWorkflowData from "../../features/reporting/hooks/useDivisionWorkflowData";

const DivisionOverviewPage = () => {
  const { division, departments, kpis } = useDivisionWorkflowData();

  const approvedCount = departments.filter((d) => d.status === "approved").length;

  return (
    <WorkspaceLayout
      role="division"
      title="Division Overview"
      subtitle="Review consolidated performance across departments before final divisional commentary."
      actions={<StatusChip status={division.status} label="Division In Review" />}
    >
      <Stack spacing={3}>
        <GlassCard>
          <CardContent>
            <Box className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-4">
              <Box>
                <Typography sx={{ fontSize: 12, color: softText }}>Division</Typography>
                <Typography sx={{ fontWeight: 800, color: white }}>
                  {division.name}
                </Typography>
              </Box>

              <Box>
                <Typography sx={{ fontSize: 12, color: softText }}>Reporting Period</Typography>
                <Typography sx={{ fontWeight: 800, color: white }}>
                  {division.periodName}
                </Typography>
              </Box>

              <Box>
                <Typography sx={{ fontSize: 12, color: softText }}>Overall Score</Typography>
                <Typography sx={{ fontWeight: 800, color: white }}>
                  {division.score}%
                </Typography>
              </Box>

              <Box>
                <Typography sx={{ fontSize: 12, color: softText }}>Approved Departments</Typography>
                <Typography sx={{ fontWeight: 800, color: white }}>
                  {approvedCount} / {departments.length}
                </Typography>
              </Box>
            </Box>
          </CardContent>
        </GlassCard>

        <GlassCard>
          <CardContent>
            <Box className="mb-3 flex items-center justify-between gap-3">
              <Typography sx={{ fontSize: 18, fontWeight: 800 }}>
                Department Roll-up
              </Typography>

              <Button
                variant="contained"
                sx={{ textTransform: "none", fontWeight: 700 }}
              >
                Proceed to Commentary
              </Button>
            </Box>

            <Stack spacing={2}>
              {departments.map((item) => (
                <Box
                  key={item.id}
                  sx={{
                    p: 2,
                    border: `1px solid ${line}`,
                    borderRadius: 3,
                    bgcolor: panel2,
                  }}
                >
                  <Box className="flex flex-col gap-4 xl:flex-row xl:items-center xl:justify-between">
                    <Box className="grid grid-cols-1 gap-3 md:grid-cols-2 xl:grid-cols-4 xl:gap-6">
                      <Box>
                        <Typography sx={{ fontSize: 12, color: softText }}>
                          Department
                        </Typography>
                        <Typography sx={{ fontWeight: 800, color: white }}>
                          {item.department}
                        </Typography>
                      </Box>

                      <Box>
                        <Typography sx={{ fontSize: 12, color: softText }}>
                          Owner
                        </Typography>
                        <Typography sx={{ fontWeight: 800, color: white }}>
                          {item.owner}
                        </Typography>
                      </Box>

                      <Box>
                        <Typography sx={{ fontSize: 12, color: softText }}>
                          Score
                        </Typography>
                        <Typography sx={{ fontWeight: 800, color: white }}>
                          {item.score}%
                        </Typography>
                      </Box>

                      <Box>
                        <Typography sx={{ fontSize: 12, color: softText }}>
                          Status
                        </Typography>
                        <Box sx={{ mt: 0.5 }}>
                          <StatusChip status={item.status} />
                        </Box>
                      </Box>
                    </Box>

                    <Box sx={{ maxWidth: 360 }}>
                      <Typography sx={{ fontSize: 12, color: softText }}>
                        Highlights
                      </Typography>
                      <Typography sx={{ color: white, mt: 0.4 }}>
                        {item.highlights}
                      </Typography>
                    </Box>
                  </Box>
                </Box>
              ))}
            </Stack>
          </CardContent>
        </GlassCard>

        <GlassCard>
          <CardContent>
            <Typography sx={{ fontSize: 18, fontWeight: 800, mb: 2 }}>
              Divisional KPI Summary
            </Typography>

            <Stack spacing={2}>
              {kpis.map((kpi) => (
                <Box key={kpi.name}>
                  <Box className="mb-1.5 flex items-center justify-between gap-3">
                    <Box>
                      <Typography sx={{ color: white, fontWeight: 800 }}>
                        {kpi.name}
                      </Typography>
                      <Typography sx={{ color: softText, fontSize: 12.5 }}>
                        Target: {kpi.target} • Actual: {kpi.actual}
                      </Typography>
                    </Box>

                    <Typography sx={{ color: white, fontWeight: 800 }}>
                      {kpi.achievement.toFixed(1)}%
                    </Typography>
                  </Box>

                  <LinearProgress
                    variant="determinate"
                    value={Math.min(kpi.achievement, 100)}
                    sx={{
                      height: 9,
                      borderRadius: 999,
                      bgcolor: "rgba(255,255,255,0.08)",
                      "& .MuiLinearProgress-bar": {
                        borderRadius: 999,
                      },
                    }}
                  />
                </Box>
              ))}
            </Stack>
          </CardContent>
        </GlassCard>
      </Stack>
    </WorkspaceLayout>
  );
};

export default DivisionOverviewPage;