import React, { useEffect, useMemo, useState } from "react";
import { Box, Stack, Typography } from "@mui/material";
import { useSearchParams } from "react-router-dom";

import RiskItemsToolbar from "../../components/riskregister/dashboard/RiskItemsToolbar";
import RiskItemsTable from "../../components/riskregister/dashboard/RiskItemsTable";

import { mockRiskItems } from "../../data/riskregister/mockRiskDashboard";
import { filterRiskItemsForList } from "../../utils/riskregister/mockRiskSelectors";

const RiskItemsPage = () => {
  const [searchParams] = useSearchParams();

  const [filters, setFilters] = useState({
    search: "",
    category: "all",
    department: "all",
    rating: "all",
    status: "all",
  });

  useEffect(() => {
    const rating = searchParams.get("rating");
    const status = searchParams.get("status");
    const category = searchParams.get("category");
    const department = searchParams.get("department");

    setFilters((prev) => ({
      ...prev,
      rating: rating || prev.rating,
      status: status || prev.status,
      category: category || prev.category,
      department: department || prev.department,
    }));
  }, [searchParams]);

  const rows = useMemo(
    () => filterRiskItemsForList(mockRiskItems, filters),
    [filters]
  );

  return (
    <Box sx={{ p: { xs: 2, md: 3 } }}>
      <Stack spacing={3}>
        <Box>
          <Typography variant="h4" fontWeight={800}>
            Risk Items
          </Typography>
          <Typography variant="body1" color="text.secondary">
            Browse, search, and review registered risks across the organisation.
          </Typography>
        </Box>

        <RiskItemsToolbar filters={filters} onChange={setFilters} />
        <RiskItemsTable rows={rows} />
      </Stack>
    </Box>
  );
};

export default RiskItemsPage;