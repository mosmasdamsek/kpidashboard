import React from "react";
import { Box, Typography } from "@mui/material";

const RiskRegistersPage = () => {
  return (
    <Box p={3}>
      <Typography variant="h5" fontWeight={700}>
        Risk Registers
      </Typography>
    </Box>
  );
};

export default RiskRegistersPage;