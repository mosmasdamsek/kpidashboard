import React from "react";
import {
  Box,
  Chip,
  Grid,
  Paper,
  Stack,
  Typography,
} from "@mui/material";
import { useParams } from "react-router-dom";

import {
  mockRiskItems,
  mockRiskActionsByRiskId,
  mockRiskReviewsByRiskId,
} from "../../data/riskregister/mockRiskDashboard";

const ratingColorMap = {
  Critical: "error",
  High: "warning",
  Medium: "info",
  Low: "success",
};

const statusColorMap = {
  Open: "default",
  "In Progress": "info",
  Closed: "success",
};

const InfoBlock = ({ label, value }) => (
  <Box>
    <Typography variant="caption" color="text.secondary">
      {label}
    </Typography>
    <Typography variant="body1" sx={{ mt: 0.5 }}>
      {value || "—"}
    </Typography>
  </Box>
);

const RiskItemDetailPage = () => {
  const { id } = useParams();
  const risk = mockRiskItems.find((item) => String(item.id) === String(id));

  if (!risk) {
    return (
      <Box sx={{ p: 3 }}>
        <Typography variant="h5" fontWeight={700}>
          Risk not found
        </Typography>
      </Box>
    );
  }

  const actions = mockRiskActionsByRiskId[risk.id] || [];
  const reviews = mockRiskReviewsByRiskId[risk.id] || [];
  const inherentScore = (risk.likelihood || 0) * (risk.impact || 0);

  return (
    <Box sx={{ p: { xs: 2, md: 3 } }}>
      <Stack spacing={3}>
        <Paper sx={{ p: 3, borderRadius: 4 }}>
          <Stack spacing={2}>
            <Stack
              direction={{ xs: "column", md: "row" }}
              justifyContent="space-between"
              alignItems={{ xs: "flex-start", md: "center" }}
              spacing={2}
            >
              <Box>
                <Typography variant="h4" fontWeight={800}>
                  {risk.risk_number}
                </Typography>
                <Typography variant="body1" color="text.secondary" sx={{ mt: 1 }}>
                  {risk.description}
                </Typography>
              </Box>

              <Stack direction="row" spacing={1} flexWrap="wrap" useFlexGap>
                <Chip
                  label={risk.rating}
                  color={ratingColorMap[risk.rating] || "default"}
                  variant="outlined"
                />
                <Chip
                  label={risk.status}
                  color={statusColorMap[risk.status] || "default"}
                  variant="outlined"
                />
                <Chip label={risk.category} variant="outlined" />
              </Stack>
            </Stack>
          </Stack>
        </Paper>

        <Grid container spacing={3}>
          <Grid item xs={12} lg={8}>
            <Paper sx={{ p: 3, borderRadius: 4 }}>
              <Stack spacing={2.5}>
                <Typography variant="h6" fontWeight={700}>
                  Risk Overview
                </Typography>

                <InfoBlock label="Department" value={risk.department} />
                <InfoBlock label="Owner" value={risk.owner} />
                <InfoBlock label="Contributing Factors" value={risk.contributing_factors} />
                <InfoBlock label="Consequences" value={risk.consequences} />
                <InfoBlock label="Existing Controls" value={risk.existing_controls} />
                <InfoBlock
                  label="Future Mitigation Summary"
                  value={risk.future_mitigation_summary}
                />
                <InfoBlock label="Response Strategy" value={risk.response_strategy} />
              </Stack>
            </Paper>
          </Grid>

          <Grid item xs={12} lg={4}>
            <Paper sx={{ p: 3, borderRadius: 4 }}>
              <Stack spacing={2.5}>
                <Typography variant="h6" fontWeight={700}>
                  Assessment
                </Typography>

                <InfoBlock label="Likelihood" value={risk.likelihood} />
                <InfoBlock label="Impact" value={risk.impact} />
                <InfoBlock label="Inherent Score" value={inherentScore} />
                <InfoBlock label="Rating" value={risk.rating} />
                <InfoBlock label="Last Review Date" value={risk.last_review_date} />
                <InfoBlock label="Next Review Date" value={risk.next_review_date} />
              </Stack>
            </Paper>
          </Grid>

          <Grid item xs={12} lg={7}>
            <Paper sx={{ p: 3, borderRadius: 4 }}>
              <Stack spacing={2}>
                <Typography variant="h6" fontWeight={700}>
                  Mitigation Actions
                </Typography>

                {actions.length === 0 ? (
                  <Typography color="text.secondary">No actions recorded.</Typography>
                ) : (
                  actions.map((action) => (
                    <Paper
                      key={action.id}
                      variant="outlined"
                      sx={{ p: 2, borderRadius: 3 }}
                    >
                      <Stack spacing={1}>
                        <Stack
                          direction={{ xs: "column", sm: "row" }}
                          justifyContent="space-between"
                          spacing={1}
                        >
                          <Typography fontWeight={700}>{action.action}</Typography>
                          <Chip
                            label={action.status}
                            size="small"
                            variant="outlined"
                            color={
                              action.status === "Completed"
                                ? "success"
                                : action.status === "Overdue"
                                ? "warning"
                                : "info"
                            }
                          />
                        </Stack>

                        <Typography variant="body2" color="text.secondary">
                          Owner: {action.owner}
                        </Typography>
                        <Typography variant="body2" color="text.secondary">
                          Due Date: {action.due_date}
                        </Typography>
                        <Typography variant="body2">
                          {action.progress_notes}
                        </Typography>
                      </Stack>
                    </Paper>
                  ))
                )}
              </Stack>
            </Paper>
          </Grid>

          <Grid item xs={12} lg={5}>
            <Paper sx={{ p: 3, borderRadius: 4 }}>
              <Stack spacing={2}>
                <Typography variant="h6" fontWeight={700}>
                  Review History
                </Typography>

                {reviews.length === 0 ? (
                  <Typography color="text.secondary">No reviews recorded.</Typography>
                ) : (
                  reviews.map((review) => (
                    <Paper
                      key={review.id}
                      variant="outlined"
                      sx={{ p: 2, borderRadius: 3 }}
                    >
                      <Stack spacing={0.75}>
                        <Typography fontWeight={700}>
                          {review.review_date}
                        </Typography>
                        <Typography variant="body2" color="text.secondary">
                          Reviewer: {review.reviewer}
                        </Typography>
                        <Typography variant="body2">{review.comments}</Typography>
                      </Stack>
                    </Paper>
                  ))
                )}
              </Stack>
            </Paper>
          </Grid>
        </Grid>
      </Stack>
    </Box>
  );
};

export default RiskItemDetailPage;