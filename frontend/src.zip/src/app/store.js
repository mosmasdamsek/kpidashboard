import { configureStore } from "@reduxjs/toolkit";
import executiveDashboardReducer from "../features/executiveDashboard/executiveDashboardSlice";
import { dashboardApi } from "../services/dashboardApi";
import { apiSlice } from "./apiSlice";

export const store = configureStore({
  reducer: {
    executiveDashboard: executiveDashboardReducer,
    [dashboardApi.reducerPath]: dashboardApi.reducer,
    [apiSlice.reducerPath]: apiSlice.reducer,
  },
  middleware: (getDefaultMiddleware) =>
    getDefaultMiddleware()
      .concat(dashboardApi.middleware)
      .concat(apiSlice.middleware),
});

export default store;