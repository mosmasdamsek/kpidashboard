import { apiSlice } from "../../app/apiSlice";

export const riskRegisterApi = apiSlice.injectEndpoints({
  endpoints: (builder) => ({
    getRiskDashboardSummary: builder.query({
      query: (params) => ({
        url: "/risk-register/dashboard/summary/",
        params,
      }),
      providesTags: ["RiskDashboard"],
    }),

    getRisksByCategory: builder.query({
      query: (params) => ({
        url: "/risk-register/dashboard/by-category/",
        params,
      }),
      providesTags: ["RiskDashboard"],
    }),

    getRisksByDivision: builder.query({
      query: (params) => ({
        url: "/risk-register/dashboard/by-division/",
        params,
      }),
      providesTags: ["RiskDashboard"],
    }),

    getRiskTrend: builder.query({
      query: (params) => ({
        url: "/risk-register/dashboard/trend/",
        params,
      }),
      providesTags: ["RiskDashboard"],
    }),

    getRiskHeatmap: builder.query({
      query: (params) => ({
        url: "/risk-register/dashboard/heatmap/",
        params,
      }),
      providesTags: ["RiskDashboard"],
    }),

    getCriticalRisks: builder.query({
      query: (params) => ({
        url: "/risk-register/dashboard/critical-risks/",
        params,
      }),
      providesTags: ["RiskDashboard", "RiskItem"],
    }),

    getOverdueActions: builder.query({
      query: (params) => ({
        url: "/risk-register/dashboard/overdue-actions/",
        params,
      }),
      providesTags: ["RiskDashboard", "RiskAction"],
    }),

    getUpcomingReviews: builder.query({
      query: (params) => ({
        url: "/risk-register/dashboard/upcoming-reviews/",
        params,
      }),
      providesTags: ["RiskDashboard", "RiskReview"],
    }),
  }),
});

export const {
  useGetRiskDashboardSummaryQuery,
  useGetRisksByCategoryQuery,
  useGetRisksByDivisionQuery,
  useGetRiskTrendQuery,
  useGetRiskHeatmapQuery,
  useGetCriticalRisksQuery,
  useGetOverdueActionsQuery,
  useGetUpcomingReviewsQuery,
} = riskRegisterApi;